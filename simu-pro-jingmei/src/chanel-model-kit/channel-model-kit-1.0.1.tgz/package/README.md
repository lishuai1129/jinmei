# channel-model-kit 使用说明

这是给 Vue2 项目使用的信道模型组件包，包含 10 个模型的配置弹窗、链路监控面板、请求 payload 构造方法。

## 1. 安装

把 `channel-model-kit-1.0.1.tgz` 放到 Vue2 项目里，然后安装：

```bash
npm install ./channel-model-kit-1.0.1.tgz
```

如果文件在其他目录，也可以直接写完整路径：

```bash
npm install "E:\jinmei\simu-pro-jingmei\src\chanel-model-kit\channel-model-kit-1.0.1.tgz"
```

## 2. 在 main.js 里注册

```js
import Vue from 'vue'
import App from './App.vue'

import ChannelModelKit from 'channel-model-kit'
import 'channel-model-kit/style.css'

Vue.use(ChannelModelKit, {
  endpoints: {
    ttc: { post: '/ttc', latest: '/ttc-latest' },
    coordination: { post: '/coordination', latest: '/coordination-latest' },
    adhoc: { post: '/adhoc', latest: '/adhoc-latest' },
    vhf: { post: '/vhf', latest: '/vhf-latest' },
    uhf: { post: '/uhf', latest: '/uhf-latest' },
    fiveG: { post: '/5g', latest: '/5g-latest' },
    dss: { post: '/dsss', latest: '/dsss-latest' },
    fhss: { post: '/fhss', latest: '/fhss-latest' },
    gfsk: { post: '/gfsk', latest: '/gfsk-latest' },
    custom: { post: '/choose', latest: '/choose-latest' }
  }
})

new Vue({
  render: h => h(App)
}).$mount('#app')
```

`style.css` 必须引入，否则弹窗和面板没有样式。

## 3. 后端代理

`main.js` 里写的是前端相对路径。真实后端地址建议写在代理配置里。

Vite 示例：

```js
import { defineConfig } from 'vite'
import vue2 from '@vitejs/plugin-vue2'

const latestTarget = 'http://10.16.55.140:8080'
const processTarget = 'http://10.16.55.140:9000'

export default defineConfig({
  plugins: [vue2()],
  server: {
    proxy: {
      '/vhf-latest': {
        target: latestTarget,
        changeOrigin: true,
        rewrite: () => '/latest'
      },
      '/vhf': {
        target: processTarget,
        changeOrigin: true,
        rewrite: () => '/vhf/process'
      }
    }
  }
})
```

其他模型按同样方式配置即可：

| 前端路径 | 后端路径 |
| --- | --- |
| `/ttc` | `/ckl/process` |
| `/coordination` | `/xtl/process` |
| `/adhoc` | `/zzw/process` |
| `/vhf` | `/vhf/process` |
| `/uhf` | `/uhf/process` |
| `/5g` | `/5g/process` |
| `/dsss` | `/sw/process` |
| `/fhss` | `/mlw/process` |
| `/gfsk` | `/satellite/process` |
| `/choose` | `/choose/process` |

所有 `xxx-latest` 都可以代理到：

```text
/latest
```

## 4. 页面里准备挂载点

```vue
<template>
  <div>
    <button @click="openConfig('vhf')">打开 VHF 配置</button>
    <button @click="openMonitor('vhf')">打开 VHF 监控</button>

    <div ref="dialogRoot"></div>
    <div ref="monitorRoot"></div>
  </div>
</template>
```

## 5. 打开配置弹窗

```js
openConfig(modelType) {
  this.dialogHandle = this.$channelModelKit.mountModelConfigDialog(this.$refs.dialogRoot, {
    visible: true,
    modelType,
    position: { lat: 30, lon: 100, alt: 0 },
    nodeId: 1,
    onConfirm: async config => {
      this.dialogHandle.update({ visible: false })
      await this.postConfig(modelType, config)
    },
    onCancel: () => {
      this.dialogHandle.update({ visible: false })
    }
  })
}
```

自定义模型用：

```js
this.$channelModelKit.mountCustomConfigDialog(...)
```

其他普通模型都用：

```js
this.$channelModelKit.mountModelConfigDialog(...)
```

## 6. 配置确认后发给后端

```js
async postConfig(modelType, config) {
  const extra = {
    node_id: 1,
    tx: { lat: 30, lon: 100, alt: 1000 },
    rx: { lat: 30.18, lon: 100, alt: 0 },
    payload: [72, 101, 108, 108, 111]
  }

  const api = this.$channelModelKit.api

  const payload = api.buildRequestPayload(modelType, config, extra)

  await api.postModel(modelType, payload)

  const latest = await api.getLatest(modelType)

  this.openMonitor(modelType, latest)
}
```

这里的 `tx/rx` 经纬度高度需要 Vue2 项目自己从地图、节点、链路里取出来传入。

## 7. 打开链路监控

```js
openMonitor(modelType, data) {
  if (this.monitorHandle) {
    this.monitorHandle.unmount()
  }

  this.monitorHandle = this.$channelModelKit.mountLinkMonitor(this.$refs.monitorRoot, {
    visible: true,
    model: modelType,
    data,
    title: '链路监控',
    onClose: () => {
      this.monitorHandle.update({ visible: false })
    }
  })
}
```

如果只是想请求 latest 后打开：

```js
async openMonitorFromLatest(modelType) {
  const data = await this.$channelModelKit.api.getLatest(modelType)
  this.openMonitor(modelType, data)
}
```

## 8. 支持的模型 key

```js
ttc          // 测控链
coordination // 协同链
adhoc        // 自组网
vhf          // VHF
uhf          // UHF
fiveG        // 5G通信
dss          // 短波
fhss         // 中长波
gfsk         // 卫星
custom       // 自定义模型
```

## 9. 常见问题

### 样式不生效

检查是否写了：

```js
import 'channel-model-kit/style.css'
```

### POST 404

一般是代理端口或 rewrite 路径不对。

比如 `/adhoc` 应该转到：

```text
http://后端:9000/zzw/process
```

不要转到：

```text
http://后端:8080/zzw/process
```

`8080` 通常只拿 `/latest`。

### latest 是空

如果后端返回：

```json
{}
```

前端没有数据可画图。可以 POST 后等一小会儿再 GET latest，或者轮询几次。

### 页面销毁时要清理

```js
beforeDestroy() {
  if (this.dialogHandle) this.dialogHandle.unmount()
  if (this.monitorHandle) this.monitorHandle.unmount()
}
```

## 10. 更新包

包源码改完后，在包目录执行：

```bash
cd src/chanel-model-kit
npm run pack:local
```

会生成新的：

```text
channel-model-kit-1.0.1.tgz
```

Vue2 项目重新安装即可：

```bash
npm install ./channel-model-kit-1.0.1.tgz
```
