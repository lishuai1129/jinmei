# channel-model-kit

独立的信道模型组件包，面向 Vue2 项目集成。包内部自带 Vue3 运行时和 ECharts，宿主项目不需要升级到 Vue3。

## 包含的模型

- 测控链 `ttc`
- 协同链 `coordination`
- 自组网 `adhoc`
- VHF `vhf`
- UHF `uhf`
- 5G通信 `fiveG`
- 短波 `dss`
- 中长波 `fhss`
- 卫星 `gfsk`
- 自定义模型 `custom`

散射/GMSK 不会出现在导出模型列表中。

## 打包

在当前目录执行：

```bash
cd src/chanel-model-kit
npm run build
npm pack
```

会生成：

```text
dist/channel-model-kit.es.js
dist/channel-model-kit.iife.js
dist/style.css
dist/index.d.ts
channel-model-kit-1.0.0.tgz
```

## Vue2 项目安装

```bash
npm install ./channel-model-kit-1.0.0.tgz
```

在入口文件中注册：

```js
import Vue from 'vue'
import ChannelModelKit from 'channel-model-kit'
import 'channel-model-kit/style.css'

Vue.use(ChannelModelKit, {
  baseUrl: '',
  endpoints: {
    dss: { post: '/dsss', latest: '/dsss-latest' },
    fhss: { post: '/fhss', latest: '/fhss-latest' },
    gfsk: { post: '/gfsk', latest: '/gfsk-latest' },
    ttc: { post: '/ttc', latest: '/ttc-latest' },
    adhoc: { post: '/adhoc', latest: '/adhoc-latest' },
    coordination: { post: '/coordination', latest: '/coordination-latest' },
    vhf: { post: '/vhf', latest: '/vhf-latest' },
    uhf: { post: '/uhf', latest: '/uhf-latest' },
    fiveG: { post: '/5g', latest: '/5g-latest' },
    custom: { post: '/choose', latest: '/choose-latest' }
  }
})
```

## Vue2 中挂载链路监控

```html
<template>
  <div>
    <div ref="monitor"></div>
  </div>
</template>
```

```js
export default {
  mounted() {
    this.monitorHandle = this.$channelModelKit.mountLinkMonitor(this.$refs.monitor, {
      visible: true,
      model: 'fiveG',
      link: this.currentLink,
      data: this.latestFiveGData,
      onClose: () => {
        this.monitorHandle.update({ visible: false })
      }
    })
  },
  watch: {
    latestFiveGData(data) {
      this.monitorHandle && this.monitorHandle.update({ data })
    }
  },
  beforeDestroy() {
    this.monitorHandle && this.monitorHandle.unmount()
  }
}
```

## Vue2 中挂载配置弹窗

```js
this.dialogHandle = this.$channelModelKit.mountModelConfigDialog(this.$refs.dialogRoot, {
  visible: true,
  modelType: 'dss',
  position: { lat: 30, lon: 100, alt: 0 },
  onConfirm: (config) => {
    console.log('配置结果', config)
    this.dialogHandle.update({ visible: false })
  },
  onCancel: () => {
    this.dialogHandle.update({ visible: false })
  }
})
```

自定义模型使用：

```js
this.$channelModelKit.mountCustomConfigDialog(this.$refs.dialogRoot, {
  visible: true,
  onConfirm: (config) => {}
})
```

## 直接 script 引入

```html
<link rel="stylesheet" href="./dist/style.css">
<script src="./dist/channel-model-kit.iife.js"></script>
<script>
  const handle = ChannelModelKit.mountLinkMonitor('#monitor', {
    model: 'uhf',
    data: latestData
  })
</script>
```
